﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApp.Context;
using WebApp.Models;
using WebApp.ViewModels;

namespace WebApp.Controllers
{
    public class LoginController : Controller
    {
        MyContext myContext;
        public LoginController(MyContext myContext)
        {
            this.myContext = myContext;
        }

        //Login
        //Get
        public IActionResult Login()
        {

            return View();
        }

        //Post
        [HttpPost]
        public IActionResult Login(string email, string password)
        {
            var data = myContext.Users
                .Include(x => x.Employee)
                .Include(x=> x.Role )
                .SingleOrDefault(x => x.Employee.Email.Equals(email) && x.Password.Equals(password));
            ResponseLogin responseLogin = new ResponseLogin()
            {
                Fullname = data.Employee.FullName,
                Email = data.Employee.Email,
                Role = data.Role.Name

            };
            if (data != null)
            {
                return RedirectToAction("Index", "Home");
            }
            return View();
        }


        // register
        //Get
        public IActionResult Register()
        {
            return View();
        }

        //Post
        [HttpPost]
        
        public IActionResult Register(string fullName, string email, string password, DateTime birthDate)
        {
            Employee employee = new Employee()
            {
                FullName = fullName,
                Email = email,
                BirthDate = birthDate,

            };
            myContext.Employees.Add(employee);
            var result = myContext.SaveChanges();
            if (result >0)
            {
                var id = myContext.Employees.SingleOrDefault(x => x.Email.Equals(email)).Id;
                User user = new User()
                {
                    Id = id,
                    Password = password,
                    RoleId = 1
                };
                myContext.Users.Add(user);
                var resultUser=myContext.SaveChanges();
                if (resultUser > 0)
                    return RedirectToAction("Login", "Login");
            }
            return View();
        }

        //Change pasword
        //Get
        public IActionResult ChangePassword()
        {
            return View();
        }

        //Post
        [HttpPost]
        public IActionResult ChangePassword(string email, string password)
        {
            var data = myContext.Users
                .Include(x => x.Employee)
                .SingleOrDefault(x => x.Employee.Email.Equals(email));
            if (data != null)
            {
                data.Password = password;
                myContext.Entry(data).State = EntityState.Modified;
                var result = myContext.SaveChanges();
                if (result > 0)
                    return RedirectToAction("Login", "Login");
            }
            return View();
        }

        //Forgot Password
        //Get
        public IActionResult ForgotPassword()
        {
            return View();
        }

        //Post
        [HttpPost]
        public IActionResult ForgotPassword(string email)
        {
            var data = myContext.Users
                .Include(x => x.Employee)
                .SingleOrDefault(x => x.Employee.Email.Equals(email));
            
            if (data != null)
            {
                return RedirectToAction("ChangePassword", "Login");
            }
            return View();
        }


    }
}
