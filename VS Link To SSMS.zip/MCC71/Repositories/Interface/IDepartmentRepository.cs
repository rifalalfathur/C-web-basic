﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCC71.Repositories.Interface
{
    internal interface IDepartmentRepository
    {
    }
}
